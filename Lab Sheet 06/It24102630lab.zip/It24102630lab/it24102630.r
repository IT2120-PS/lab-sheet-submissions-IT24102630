setwd("C:\\Users\\LENOVO\\OneDrive\\Videos\\Desktop\\It24102630lab")
getwd()

#01

n <- 50  
p <- 0.85

prob_at_least_47 <- dbinom(47, size = n, prob = p) + 
  dbinom(48, size = n, prob = p) + 
  dbinom(49, size = n, prob = p) + 
  dbinom(50, size = n, prob = p)


cat("\n")


#02

lambda <- 12 
print(paste("Probability of exactly 15 calls in an hour:", prob_exactly_15_calls))

